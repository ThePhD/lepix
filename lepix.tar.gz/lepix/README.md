# lepix

The classy image editing language.

# Proposal

https://github.com/ThePhD/lepix/blob/master/lepix.pdf

# Language Specification

https://github.com/ThePhD/lepix/blob/master/lepix-lang.pdf

# Report

https://github.com/ThePhD/lepix/blob/master/lepix-report.pdf

# Final Presentation

https://github.com/ThePhD/lepix/blob/master/lepix-presentation.pdf
