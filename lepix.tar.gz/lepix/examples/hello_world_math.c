#include "preamble/lib_preamble.h"

// fun main() : int {
int main() {
	// lib.print((24 + 18 * 2 / 6) % 32);
	printf("%d", (24 + 18 * 2 / 6) % 32);
// }
	return 0;
}
