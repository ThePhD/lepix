#pragma once

int ext_func();
