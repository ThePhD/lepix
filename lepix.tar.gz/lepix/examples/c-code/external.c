#include "external.h"


int ext_func() {
	return 24;
}
