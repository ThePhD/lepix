#include "preamble/lib_preamble.h"

// fun main() : int {
int main() {
	// lib.print("Hi there");
	printf("%s", "Hi there");
	// }
	return 0;
}
