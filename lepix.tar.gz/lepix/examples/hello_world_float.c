#include "preamble/lib_preamble.h"

// fun main() : int {
int main() {
	// var x : float = 10.2;
	float x = 10.2;
	// lib.print(x);
	printf("%f\n", x);
	// var y : int = 11;
	int y = 11;
	// lib.print(y);
	printf("%d\n", y);
	// lib.print((x / 2) + (y / 2));
	printf("%f\n", (x / 2) + (y / 2));
// }
	return 0;
}
