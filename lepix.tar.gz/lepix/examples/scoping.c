#include "preamble/lib_preamble.h"

//fun main() : int {
int main() {
	//var x : int = 24;
	int x = 24;
	//{
	{
		//var x : int = 56;
		int x = 56;
		//lib.print(x);
		printf("%d", x);
	}
	//}
	//lib.print(x);
	printf("%d", x);
//}
}
