#pragma once
// -- MEMORY PREAMBLE
#include <string.h>
#include <stdlib.h>
