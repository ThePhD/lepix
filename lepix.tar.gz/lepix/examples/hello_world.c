#include "preamble/lib_preamble.h"

// fun main() : int {
int main() {
	// lib.print(24);
	printf("%d", 24);
// }
	return 0;
}
